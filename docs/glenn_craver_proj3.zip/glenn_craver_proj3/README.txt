--Compiling Code--
Run compile.sh <--This will compile ALL files ending in .c and .h

--Running Code--
test.sh can be run. Test.sh is a copy of the shell script used in Proj 0.
You do not need to use test.sh to run the program. If you're using the same test.sh from Proj0 this program should run correctly.
This file is provided out of convenience.

--Folder Contents and Purpose of Files--
	glenn_craver_Proj3.c is the program's code.
	glenn_craver_Proj3.h contains defines for the tokens and links important files and libraries.
	syntax.h contains definitions of the nodes and several functions.