#/bin/bash
gcc -o a.out **.h  *.c
echo "Compiled program. Output as: a.out"
